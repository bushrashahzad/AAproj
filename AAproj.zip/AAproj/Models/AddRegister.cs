﻿namespace AAproj.Models
{
    public class AddRegister
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public string date { get; set; }
    }
}
